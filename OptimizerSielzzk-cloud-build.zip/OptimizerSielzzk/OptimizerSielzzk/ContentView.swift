import SwiftUI
import UIKit
import Security

private enum OptimizerStyle {
    static let red = Color(red: 1.0, green: 0.16, blue: 0.19)
    static let blue = Color(red: 0.12, green: 0.48, blue: 1.0)
    static let background = Color(red: 0.025, green: 0.027, blue: 0.035)
    static let panel = Color(red: 0.075, green: 0.08, blue: 0.095)
    static let muted = Color(red: 0.62, green: 0.64, blue: 0.69)
}

struct ContentView: View {
    @State private var password = ""
    @State private var showPassword = false
    @State private var savePassword = false
    @State private var authenticated = false
    @State private var selectedTab = 0
    @State private var isLaunching = false
    @State private var countdown = 10
    @State private var showLaunchAlert = false
    @State private var launchMessage = ""
    @State private var launchTask: Task<Void, Never>?

    var body: some View {
        ZStack {
            OptimizerStyle.background.ignoresSafeArea()
            ParticleCanvas()
                .ignoresSafeArea()
                .opacity(0.9)

            if authenticated {
                dashboard
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
            } else {
                loginScreen
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.35), value: authenticated)
        .alert("Optimizer Sielzzk", isPresented: $showLaunchAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(launchMessage)
        }
        .onAppear(perform: restoreSavedPassword)
        .onDisappear { launchTask?.cancel() }
    }

    private var loginScreen: some View {
        VStack(spacing: 22) {
            Spacer(minLength: 24)
            Image("OptimizerLogo")
                .resizable()
                .scaledToFill()
                .frame(width: 142, height: 142)
                .clipShape(RoundedRectangle(cornerRadius: 34))
                .overlay(RoundedRectangle(cornerRadius: 34).stroke(OptimizerStyle.red.opacity(0.8), lineWidth: 1.5))
                .shadow(color: OptimizerStyle.red.opacity(0.28), radius: 24)

            VStack(spacing: 6) {
                Text("OPTIMIZER")
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .tracking(3)
                Text("SIELZZK  •  GAME TOOLS")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(OptimizerStyle.red)
            }

            VStack(alignment: .leading, spacing: 10) {
                Text("SENHA DE ACESSO")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.6)
                    .foregroundStyle(OptimizerStyle.muted)
                HStack(spacing: 12) {
                    Image(systemName: "lock.fill")
                        .foregroundStyle(OptimizerStyle.red)
                    Group {
                        if showPassword {
                            TextField("Digite sua senha", text: $password)
                        } else {
                            SecureField("Digite sua senha", text: $password)
                        }
                    }
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    Button {
                        showPassword.toggle()
                    } label: {
                        Image(systemName: showPassword ? "eye.slash.fill" : "eye.fill")
                            .foregroundStyle(OptimizerStyle.muted)
                    }
                    .accessibilityLabel(showPassword ? "Esconder senha" : "Mostrar senha")
                }
                .padding(.horizontal, 16)
                .frame(height: 56)
                .background(OptimizerStyle.panel)
                .clipShape(RoundedRectangle(cornerRadius: 15))
                .overlay(RoundedRectangle(cornerRadius: 15).stroke(.white.opacity(0.08), lineWidth: 1))

                Button {
                    savePassword.toggle()
                    if !savePassword { KeychainPassword.delete() }
                } label: {
                    HStack(spacing: 9) {
                        Image(systemName: savePassword ? "checkmark.square.fill" : "square")
                            .foregroundStyle(savePassword ? OptimizerStyle.red : OptimizerStyle.muted)
                        Text("Salvar minha senha")
                            .foregroundStyle(OptimizerStyle.muted)
                            .font(.system(size: 13, weight: .medium))
                        Spacer()
                    }
                }
                .buttonStyle(.plain)
                .padding(.top, 3)
            }
            .padding(20)
            .background(OptimizerStyle.panel.opacity(0.82))
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.07), lineWidth: 1))

            Button(action: signIn) {
                HStack {
                    Text("ENTRAR")
                    Image(systemName: "arrow.right")
                }
                .font(.system(size: 14, weight: .black, design: .rounded))
                .tracking(1.5)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 55)
                .background(LinearGradient(colors: [OptimizerStyle.red, Color(red: 0.72, green: 0.04, blue: 0.09)], startPoint: .leading, endPoint: .trailing))
                .clipShape(RoundedRectangle(cornerRadius: 15))
                .shadow(color: OptimizerStyle.red.opacity(0.22), radius: 16, y: 6)
            }
            .buttonStyle(.plain)

            Text("ACESSO PROTEGIDO • SIELZZK")
                .font(.system(size: 9, weight: .semibold, design: .rounded))
                .tracking(1.5)
                .foregroundStyle(.white.opacity(0.3))
            Spacer(minLength: 24)
        }
        .padding(.horizontal, 25)
        .frame(maxWidth: 440)
    }

    private var dashboard: some View {
        VStack(spacing: 18) {
            HStack(spacing: 12) {
                Image("OptimizerLogo")
                    .resizable().scaledToFill()
                    .frame(width: 48, height: 48)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading, spacing: 3) {
                    Text("OPTIMIZER SIELZZK")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                        .tracking(1)
                    Text("PAINEL DE OTIMIZAÇÃO")
                        .font(.system(size: 9, weight: .bold))
                        .tracking(1.6)
                        .foregroundStyle(OptimizerStyle.red)
                }
                Spacer()
                Button {
                    authenticated = false
                    password = ""
                } label: {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(OptimizerStyle.muted)
                        .padding(12)
                        .background(OptimizerStyle.panel)
                        .clipShape(Circle())
                }
                .accessibilityLabel("Sair")
            }

            HStack(spacing: 10) {
                tabButton("DESEMPENHO", icon: "gauge.with.dots.needle.67", index: 0)
                tabButton("JOGO", icon: "gamecontroller.fill", index: 1)
            }
            .padding(5)
            .background(OptimizerStyle.panel)
            .clipShape(RoundedRectangle(cornerRadius: 15))

            ScrollView(showsIndicators: false) {
                VStack(spacing: 12) {
                    if selectedTab == 0 {
                        featureCard(title: "Reduzir lag", description: "Atalho para conferir ajustes básicos do aparelho e dicas para reduzir travamentos durante a partida.", icon: "bolt.fill", tag: "ESTABILIDADE")
                        featureCard(title: "Melhorar desempenho", description: "Mostra recomendações para fechar apps em segundo plano, liberar espaço e manter o aparelho resfriado.", icon: "speedometer", tag: "DESEMPENHO")
                    } else {
                        featureCard(title: "Melhorar gráfico", description: "Exibe orientações para escolher uma configuração gráfica equilibrada entre qualidade e fluidez.", icon: "sparkles", tag: "GRÁFICOS")
                        featureCard(title: "Ajuste de sensibilidade aprimorado", description: "Área para consultar e organizar suas preferências de sensibilidade. Os valores do jogo devem ser ajustados dentro do próprio Free Fire.", icon: "scope", tag: "CONTROLE")
                    }
                }
                .padding(.vertical, 2)
            }

            VStack(spacing: 12) {
                Button(action: activateInGame) {
                    HStack(spacing: 11) {
                        if isLaunching {
                            ProgressView().tint(.white)
                            Text("CARREGANDO... \(countdown)s")
                        } else {
                            Image(systemName: "play.fill")
                            Text("ATIVAR NO JOGO")
                        }
                    }
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .tracking(1.2)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 58)
                    .background(OptimizerStyle.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: OptimizerStyle.blue.opacity(0.25), radius: 15, y: 5)
                }
                .disabled(isLaunching)
                .buttonStyle(.plain)
                Text("O jogo será aberto pelo link freefire:// após o carregamento")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(OptimizerStyle.muted)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 18)
        .padding(.bottom, 14)
        .frame(maxWidth: 520)
    }

    private func tabButton(_ title: String, icon: String, index: Int) -> some View {
        Button { withAnimation(.easeInOut(duration: 0.2)) { selectedTab = index } } label: {
            HStack(spacing: 7) {
                Image(systemName: icon)
                Text(title)
            }
            .font(.system(size: 10, weight: .black, design: .rounded))
            .tracking(0.5)
            .foregroundStyle(selectedTab == index ? .white : OptimizerStyle.muted)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(selectedTab == index ? OptimizerStyle.red.opacity(0.88) : .clear)
            .clipShape(RoundedRectangle(cornerRadius: 11))
        }
        .buttonStyle(.plain)
    }

    private func featureCard(title: String, description: String, icon: String, tag: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(OptimizerStyle.red)
                    .frame(width: 42, height: 42)
                    .background(OptimizerStyle.red.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.system(size: 15, weight: .bold, design: .rounded)).foregroundStyle(.white)
                    Text(tag).font(.system(size: 8, weight: .black)).tracking(1.5).foregroundStyle(OptimizerStyle.red)
                }
                Spacer()
                Image(systemName: "checkmark.circle.fill").foregroundStyle(.white.opacity(0.25))
            }
            Text(description)
                .font(.system(size: 12, weight: .regular))
                .foregroundStyle(OptimizerStyle.muted)
                .lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(OptimizerStyle.panel.opacity(0.94))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.065), lineWidth: 1))
    }

    private func signIn() {
        guard password == "optmizer2026" else {
            launchMessage = "Senha incorreta. Confira e tente novamente."
            showLaunchAlert = true
            return
        }
        if savePassword { KeychainPassword.save(password) }
        withAnimation { authenticated = true }
    }

    private func restoreSavedPassword() {
        if let saved = KeychainPassword.load() {
            password = saved
            savePassword = true
        }
    }

    private func activateInGame() {
        guard !isLaunching else { return }
        isLaunching = true
        countdown = 10
        launchTask?.cancel()
        launchTask = Task { @MainActor in
            for remaining in stride(from: 10, through: 1, by: -1) {
                countdown = remaining
                try? await Task.sleep(for: .seconds(1))
                if Task.isCancelled { return }
            }
            isLaunching = false
            guard let url = URL(string: "freefire://") else { return }
            UIApplication.shared.open(url, options: [:]) { opened in
                if !opened {
                    launchMessage = "Não foi possível abrir o Free Fire. Verifique se o jogo está instalado e se o esquema freefire:// é aceito pela versão instalada."
                    showLaunchAlert = true
                }
            }
        }
    }
}

private struct ParticleCanvas: View {
    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: false)) { timeline in
            let time = timeline.date.timeIntervalSinceReferenceDate
            Canvas { context, size in
                let points = (0..<34).map { index -> CGPoint in
                    let seed = Double(index)
                    let x = (sin(time * (0.12 + seed.truncatingRemainder(dividingBy: 5) * 0.012) + seed * 2.13) * 0.5 + 0.5) * size.width
                    let y = (cos(time * (0.10 + seed.truncatingRemainder(dividingBy: 7) * 0.009) + seed * 1.71) * 0.5 + 0.5) * size.height
                    return CGPoint(x: x, y: y)
                }
                for i in points.indices {
                    for j in points.indices where j > i {
                        let a = points[i], b = points[j]
                        let dx = a.x - b.x, dy = a.y - b.y
                        let distance = hypot(dx, dy)
                        if distance < 145 {
                            var path = Path()
                            path.move(to: a); path.addLine(to: b)
                            context.stroke(path, with: .color(OptimizerStyle.red.opacity((1 - distance / 145) * 0.19)), lineWidth: 0.65)
                        }
                    }
                    let dot = Path(ellipseIn: CGRect(x: points[i].x - 1.5, y: points[i].y - 1.5, width: 3, height: 3))
                    context.fill(dot, with: .color(OptimizerStyle.red.opacity(0.55)))
                }
            }
        }
        .allowsHitTesting(false)
    }
}

private enum KeychainPassword {
    private static let service = "com.sielzzk.optimizer"
    private static let account = "saved-login-password"

    static func save(_ password: String) {
        delete()
        guard let data = password.data(using: .utf8) else { return }
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: account,
                                    kSecValueData as String: data]
        SecItemAdd(query as CFDictionary, nil)
    }

    static func load() -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: account,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete() {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
    }
}
