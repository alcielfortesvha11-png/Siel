# Gerar IPA sem assinatura usando apenas o notebook

Este projeto inclui um workflow do GitHub Actions que compila o app em um runner macOS na nuvem. Você não precisa instalar Xcode nem ter um Mac local; precisa de navegador, internet e uma conta GitHub.

1. Entre em https://github.com e crie um repositório novo.
2. Envie todos os arquivos e pastas deste projeto para a raiz do repositório. Preserve a pasta `.github/workflows` (no seletor de arquivos, habilite a visualização de arquivos ocultos se necessário).
3. Abra a aba **Actions** do repositório.
4. Selecione **Build unsigned IPA** e toque em **Run workflow**.
5. Aguarde a execução terminar com sucesso.
6. Na página da execução, baixe o artefato **OptimizerSielzzk-unsigned-IPA**. Dentro dele estará `OptimizerSielzzk-unsigned.ipa`.
7. Transfira o IPA para o iPhone e tente assinar/importar pelo KSign.

Observações:
- O workflow gera um IPA sem assinatura; não instala diretamente no iPhone.
- A assinatura posterior precisa ser compatível com o método de instalação e com o iOS.
- O esquema `freefire://` só abre o jogo se a versão instalada registrar esse esquema.
