# Optimizer Sielzzk — projeto iOS

Projeto SwiftUI para abrir no Xcode e compilar/assinar no seu próprio dispositivo Apple.

## Abrir
1. Extraia o ZIP em um Mac com Xcode instalado.
2. Abra `OptimizerSielzzk.xcodeproj`.
3. Em **Signing & Capabilities**, selecione sua equipe Apple e ajuste o Bundle Identifier se necessário.
4. Selecione um iPhone conectado ou um destino de compilação e use **Product > Archive** para preparar a distribuição.

## Login
- Senha: `optmizer2026`
- O botão de olho alterna entre mostrar e ocultar a senha.
- A opção de salvar senha usa o Keychain do iOS.

## Abertura do Free Fire
O botão aguarda 10 segundos e tenta abrir `freefire://`. O esquema só funcionará se a versão instalada do Free Fire registrar esse URL scheme no iOS. O app não usa link alternativo.

## Limitação importante
As opções de lag, desempenho, gráficos e sensibilidade são informativas. Um app iOS comum não pode alterar diretamente a memória, os gráficos, a sensibilidade interna ou o desempenho de outro app. O projeto não injeta código no Free Fire.
